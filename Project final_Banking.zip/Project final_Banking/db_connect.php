<?php
$servername = "localhost";
$username = "root";
$password = "nhrk1115";
$database = "Banking_project";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
	header('location:server_down.php');
} 
else{
	// echo "Connection Established";
}

?>