
<?php 
include 'header.php' ;
include 'customer_profile_header.php';
if($_SESSION['customer_login'] == FALSE)
{
     header('location:customer_login.php');

}


?>
<html>
 <head><title>My Profile</title>
 <link rel="stylesheet" type="text/css" href="css/customer_profile.css" />
</head>
<body>


    <?php 
        include 'db_connect.php'; 


        $sql="select * from customer, banklogin where customer.account_num = banklogin.account_num";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $mobile_number = $row['mobile_no'];
        $Gender = $row['gender'];
        $Date_Of_Birth = $row['DOB'];
        $country = $row['country'];
        $State = $row['state'];
        $zip = $row['zip'];
        $city = $row['city'];
        

?>

    <div class="cust_profile_container">
            <div class="acc_details">
                <span class="heading">Account Details</span><br>
                <label> Gender : <?php echo $Gender; ?></label>
                <label> Date_Of_Birth : <?php echo $Date_Of_Birth; ?></label>
                <label> mobile_number : <?php echo $mobile_number; ?></label>
                <label> Country : <?php echo $country; ?></label>
                <label> City : <?php echo $city; ?></label>
                <label> Zip : <?php echo $zip; ?></label>

            </div>
 
                 <?php include 'footer.php' ; ?>
                  </label><br>
</div>

</dody>
</html>