<html>
<title>Banking System</title>
<head>
   <link rel="stylesheet" type="text/css" href="css/index.css">
   <link rel="shortcut" href="img/banklogo.jpeg">
    </head>
 
<body>
<?php include'header.php'?>
<div class="index_container">
    <div class="slider">
    <div class="slideimg">
    <img src="img/transfer.jpeg">
        <img src="img/transfer.jpeg">
        <img src="img/transfer.jpeg">
        <img src="img/transfer.jpeg">
        <img src="img/transfer.jpeg">
        </div>
    </div><br>
  
   

    
<div class="news_events">
    <h4>Guidelines | Updates </h4><br>
        <ul>
            <p> Every Customer should open an account before using Internet Banking.  If needed, can apply for debit card
 </p><br>
<p>And then, Register for internet banking.

</p>
            <br>
        </ul>
    </div>
    

    <div class="online_services">
        <h4>Online Services</h4>
        <ul>
            <a href="customer_reg_form.php"><li>Open Account</li></a>
            <a href="debit_card_form.php"><li>Apply Debit Card</li></a><br>
            <a href="#" id="ebanking" ><li><div class="ebanking">Internet Banking
                <div class = "ebanking_options">
                <ul>
                    <a href="customer_login.php"><li>Login </li></a>
                    <a href="ebanking_reg_form.php"><li>Register</li></a>
                </ul>
            </div>
        </div>
    </li></a>
            <a href="fund_transfer.php"><li>Fund Transfer</li></a><br>
        </ul>
   
</div>

        <div id="aboutus" class="about"><span>About Us</span><br><br>
        <p>
            In this UNT Denton Bank, Bank’s ownership is splits into shares among shareholders. For Bank, there are branches in different locations in different towns and cities. Each Branch maintains few ATMs located near to that branch.Bank provides personal banking and corporate banking. Only corporate banking provides offers in paying bills. And there is a limit for withdraw of money in personal banking. Each customer should have only one account opened to access all services in bank. Every customer can take loan, that is optional. Interest_rate and term of loan should be fixed while giving loan.

</p></div>
    
    <div class="disclaimer">
    <span>Disclaimer !!</spasn><br><br>
        <p>Our bank representatives does not require for the banking password. Please beware of Fraud calls.</p>
        <p>Our Bank Management is not at all responsible for online transactions going wrong.</p>
        <p>We declare, your data is not disclosed anywhere, it is safe.</p>
    </div>


    </div>
    
<?php include 'footer.php';?>
</body>

</html>