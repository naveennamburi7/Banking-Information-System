<?php ob_start() ?>

<html>
<head>
    <title>Registration Form</title>
    <link rel="stylesheet" type="text/css" href="css/customer_reg_form.css"/>
    
	<?php include'header.php';  ?>
    </head>
    <body>
    <div class="container_regfrm_container_parent">
	<h3>Online Bank Account Opening Form</h3>
	<div class="container_regfrm_container_parent_child">
		<form method="post">


				 <input type="text" name="name" placeholder="Name" required />
				 <select name ="gender" required >
					  <option class="default" value="" disabled selected>Gender</option>
					  <option value="Male" required >Male</option>
					  <option value="Female">Female</option>
					  <option value="Others">Others</option>
				</select>
				 <input type="number" name="mobile_no" placeholder="Mobile_no" required />

				
				 <input type="text" name="dob" placeholder="Date of Birth" onfocus="(this.type='date')" required />


				 <input type="text" name="address" placeholder="address: Street" required  />

				 <input type="text" name="country" placeholder="US" value="US" readonly="readonly" />



				 <select name ="state" required >
					  <option class="default" value="" disabled selected>State</option>
					  
					  <option value="California">California</option>
					  <option value="Texas">Texas</option>
					  <option value="Florida">Florida</option>
					  <option value="Washington">Washington</option>
					  <option value="Hawaii">Hawaii</option>
					  <option value="Alaska">Alaska</option>
					  <option value="Virginia">Virginia</option>
					  <option value="Idaho">Idaho</option>
				</select>



				 <select name ="city" required >
					  <option class="default" value="" disabled selected>City</option>
					  <option value="Los Angeles">Denton</option>
					  <option value="San Diego">San Diego</option>
					  <option value="Fresno">Frisco</option>
					  <option value="Houston">Houston</option>
					  <option value="Austin">Austin</option>
					  <option value="Dallas">Dallas</option>
					  <option value="Texas City">Texas City</option>
					  <option value="Miami">Miami</option>
					  <option value="Orlando">Orlando</option>
					  <option value="Jacksonville">Jacksonville</option>
					  <option value="Seattle">Dallas</option>
					  <option value="Vancouver">Vancouver</option>
					  <option value="Olympia">Olympia</option>
					  <option value="Honolulu">Honolulu</option>
					  <option value="Hawi">Hawi</option>
					  <option value="Lahaina">Lahaina</option>
					  <option value="Anchorage">Anchorage</option>
					  <option value="Sitka">Sitka</option>
					  <option value="Seward">Seward</option>
					  <option value="Richmond">Richmond</option>
					  <option value="Williamsburg">Williamsburg</option>
					  <option value="Alexandria">Alexandria</option>
					  <option value="Boise">Boise</option>
					  <option value="Twin Falls">Twin Falls</option>
					  <option value="Moscow">Moscow</option>
					  
				</select>

				 
				 <input type="text" name="zip" placeholder="zip Code" required />

				 
				 <select name ="acctype" required >
					  <option class="default" value="" disabled selected>Acctype</option>
					  <option value="Saving">Saving</option>
					  <option value="Current">Current</option>
				</select>
				<input type="submit" name="submit" value="Submit">
				</form>
         </div>
		 </div>
		 
<?php include'footer.php';?>
    
</body>
</html>


<?php 

if(isset($_POST['submit'])){

	session_start();
	$_SESSION['$cust_acopening'] = TRUE;
	$_SESSION['cust_name']=$_POST['name'];
	$_SESSION['cust_gender']=$_POST['gender'];
	$_SESSION['cust_mobile_no']=$_POST['mobile_no'];


	$_SESSION['cust_dob']=$_POST['dob'];


	$_SESSION['cust_addr']=$_POST['address'];

	$_SESSION['cust_country']=$_POST['country'];
	$_SESSION['cust_state']=$_POST['state'];
	$_SESSION['cust_city']=$_POST['city'];
	$_SESSION['cust_zip']=$_POST['zip'];




	$_SESSION['cust_acctype']=$_POST['acctype'];
	
	header('location:cust_regfrm_confirm.php');
	
	
}

?>