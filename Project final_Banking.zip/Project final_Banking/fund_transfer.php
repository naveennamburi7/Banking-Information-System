
<html>
<head><title>Fund Transfer</title>
<link rel="stylesheet" type="text/css" href="css/customer_pass_change.css"/>
<style>
#customer_profile .link3{

background-color: rgba(5, 21, 71,0.4);

}
    </style>

</head>
<body>
<?php 
	  include 'header.php';
	  include 'customer_profile_header.php';

?>
<?php
if($_SESSION['customer_login'] != true)
	
{
	
	 header('location:customer_login.php');
	

}	
	
?> 




<div class="cust_passchng_container">
<form method="post">
<br><br><input type="integer" name="account_num" placeholder="Account Number" required><br>
<input type="text" name="account_name" placeholder="Holder Name"><br>
<input type="integer" name="transfer_amount" placeholder="Transfer Amount" required><br>
<input type="submit" name="submit" placeholder=""><br><br>
</form>

</div>

<?php  include 'footer.php';  ?>
</body>
</html>

<?php  
if(isset($_POST['submit'])){
	
	
	$account_num= $_POST['account_num'];
	$account_name= $_POST['account_name'];
	$transfer_amount= $_POST['transfer_amount'];
	include 'db_connect.php';
	$banking_id=$_SESSION['banking_id'];
	
		$sql="SELECT balance from customer WHERE account_num=(select account_num from banklogin where banking_id = '$banking_id') ";
		if(!$result=$conn->query($sql)){
			
			echo "Error:1 " . $sql . "<br>" . $conn->error;
		}
		$row = $result->fetch_assoc();
	
	if($row['balance'] > $transfer_amount ){
		
		$new_balance = $row['balance'] - $transfer_amount;
		$transaction_id = rand(1,9999);
		$sql2="INSERT into onlinebanking VALUES('$transaction_id', '$account_num', '$account_name', '$transfer_amount')";
		$sql2="UPDATE customer SET  balance='$new_balance' WHERE customers.banking_id=$banking_id ";
		$conn->query($sql2);
		if($result=$conn->query($sql2)== TRUE){
			
				
				echo '<script>alert("Amount Transferred Successfully!")</script>';
			
		}
		
	}
		
		else
		{	
			echo '<script>alert("Insufficient Balance")</script>'; 
			
		}
		
		}	

			

			
?>


