<?php 
include 'header.php' ;
include 'customer_profile_header.php';
if($_SESSION['customer_login'] == FALSE)
{
	 header('location:customer_login.php');

}


?>
<html>
 <head><title>My Profile</title>
 <link rel="stylesheet" type="text/css" href="css/customer_profile.css" />
</head>
<body>
          



</body>
<?php  ?>
</html>


