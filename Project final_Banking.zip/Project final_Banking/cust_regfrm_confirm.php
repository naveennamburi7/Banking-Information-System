
<?php 
session_start();
if(!isset($_SESSION['$cust_acopening'])){
	
	header('location:customer_reg_form.php');
	
}

?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/cust_regfrm_confirm.css" />

<?php include 'header.php' ?>
<title>Confirm</title>
</head>
<body>
<div class="cust_regfrm_cnfrm_container">
<div class="cnfrm_info">
     <span><?php echo "Name : ".$_SESSION['cust_name']."<br>"; ?> </span>
     <span><?php echo "Gender : ".$_SESSION['cust_gender']."<br>"; ?> </span>
	 <span><?php echo "Mobile_No : ".$_SESSION['cust_mobile_no']."<br>"; ?> </span>
	 
	 <span><?php echo "DOB : ".$_SESSION['cust_dob']."<br>"; ?> </span>


	 <span><?php echo "address : ".$_SESSION['cust_addr']."<br>"; ?>  </span>

	 <span><?php echo "Country : ".$_SESSION['cust_country']."<br>"; ?> </span>
	 <span><?php echo "State : ".$_SESSION['cust_state']."<br>"; ?> </span>
	 <span><?php echo "City : ".$_SESSION['cust_city']."<br>"; ?> </span>
	 <span><?php echo "zip : ".$_SESSION['cust_zip']."<br>"; ?> </span>
	 <span><?php echo "acctype: ".$_SESSION['cust_acctype']."<br>"; ?> </span><br>
	 <form method="post">
	 <div class="cnfrm-btn">
	 <div class="btn_innerdiv">
	 <input class="cnfrm-submit-btn" type="submit" name="cnfrm-submit" value="Confirm" />
	 <input class="cnfrm-submit-btn" type="button" value="Go back" onclick="history.back()"/>
	 </div>
	 </div>
	 </form>
 </div>	 
</div>
</body>
<?php include 'footer.php' ?>
</html>

<?php

if(isset($_POST['cnfrm-submit'])){ 
	
	include 'db_connect.php';
	$account_num = rand(10,99).mt_rand(10000,999999);
	$name=$_SESSION['cust_name'];
	$gender=$_SESSION['cust_gender'];
	$mobile_no=$_SESSION['cust_mobile_no'];
	
	$dob=$_SESSION['cust_dob'];


	$addrs=$_SESSION['address'];

	$country=$_SESSION['cust_country'];
	$state=$_SESSION['cust_state'];
	$city=$_SESSION['cust_city'];
	$zip=$_SESSION['cust_zip'];


	$acctype=$_SESSION['cust_acctype'];
	$balance= rand(1,9).mt_rand(1000,99999);
	
	
	$sql="INSERT into customer (account_num, 
	Name,
	Gender,
	Mobile_no,
	DOB,
	addrs,
	Country,
	State,
	City,
	zip,
	acctype,
	balance)
	VALUES
	('$account_num',
	'$name',
	'$gender',
	'$mobile_no',
	'$dob',
	'$address',

	'$country',
	'$state',
	'$city',
	'$zip',

	'$acctype',
	 '$balance')";

	if($conn->query($sql) == true){
    echo "<script>alert('Account number is $account_num');location='index.php'</script>";
																											
			}
			
			else
			  
				{
				
				echo "Error: " . $sql . "<br>" . $conn->error;
			   
			   }

			}
	?>
	
