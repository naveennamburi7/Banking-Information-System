<link rel="stylesheet" type="text/css" href="css/header.css">
        <div class="header_main">
		<div class="navBar">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="index.php#aboutus">About Us</a></li>
                <li><a href="index.php#contactus">Contact Us</a></li>
				<li><a href="staff_login.php">Employee Login</a></li>
				<li><a href="staff_login.php">Share Holder</a></li>
			
			</ul>
		</div>
	 <a href="index.php"><div class="logo-name">
			<div class="logo">
             <img class="logo_img" src="img/bankioi.jpeg" width="150" height="149">
			</div>
			
			<div class="name">
				<h5>UNT Denton Bank</h5></a><br>
			</div>
        </div>
            
            
            <div class="dif_banking">
			<div class="Personal_banking">
				<a href="#">Personal Banking</a>
			</div>
			<div class="corporate_banking">
				<a href="#"> Corporate Banking</a>
			</div>
			<div class="international_banking">
				<a href="#"> Apply Mobile Banking</a>
			</div>
                
            <div class="bank_servic">
				<a href="#">Services</a>
			</div>
		</div>
            
           
			
	</div>