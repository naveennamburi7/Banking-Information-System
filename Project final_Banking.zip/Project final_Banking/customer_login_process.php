<?php  ob_start();  ?>
<?php
include 'db_connect.php';
if(isset($_POST['login-btn'])){
	
if(isset($_POST['banking_id'])){

  //with hashing
// $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

$password = $_POST['password'];
$customer_id = $_POST['banking_id'];
}
    $sql1="select * from customer, banklogin where customer.account_num = banklogin.account_num";
    $result1 = $conn->query($sql1);
    $row1 = $result1->fetch_assoc();

		$sql="SELECT * FROM banklogin where banking_id='$banking_id' and Password='$password' ";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		if($banking_id != $row['banking_id'] && $password != $row['Password']){
				
		echo '<script>alert("Incorrect Id/Password.")</script>';

	}
			
			
		else{
			
      
		$_SESSION['customer_login'] = true;
//        $_SESSION['Balance'] = $row['Current_Balance'];
		$_SESSION['name'] = $row1['name'];
		$_SESSION['account_num'] = $row1['account_num'];
		$_SESSION['Gender'] = $row1['Gender'];
		$_SESSION['mobile_no'] = $row1['mobile_no'];
		$_SESSION['DOB']	= $row1['DOB'];

		$_SESSION['city']= $row['city'];
		$_SESSION['banking_id'] = $banking_id;
		$_SESSION['acctype'] =$row1['acctype'];
	



		header('location:customer_profile.php');
		}

}



?>