<html>
<head>
    
    <title>Internet Banking Registration</title>
    <link rel="stylesheet" type="text/css" href="css/ebanking_reg_form.css">
    </head>
    <body>
       <?php include'header.php';?>
       <div class="ebanking_reg_form_container_parent">
       <h3>Internet Banking Registration</h3>
        <div class="ebanking_reg_form_container_child">
        <form method="post">

            <input type="number" name="account_num" placeholder="Account Number" required />
            <input type="password" name="password" placeholder="Password" minlength=7 required/>
            <input type="password" name="cnfrm_password" placeholder="Confirm Password" required/>
            <input type="submit" name="submit" value="Submit"/>
            </form>
            </div>
    </div>

<?php  

if(isset($_POST['submit'])){

    if(empty($_POST['account_num']) ||
    empty($_POST['password']) ||
    empty($_POST['cnfrm_password']))
    {

        echo '<script>alert("Field should not be empty")</script>';
    }

    else{

    include 'db_connect.php';
    
    $account_num=$_POST['account_num']; 

    //Without Hashing
    $password=$_POST['password'];
    $cnfrm_password = $_POST['cnfrm_password'];

   

        
        //Get Customer ID
        $sql1 = "SELECT * FROM customer WHERE account_num = '$account_num'";
        $result1 = $conn->query($sql1);
        $row1 = $result1->fetch_assoc();
        
        $sql2 = "SELECT * FROM banklogin WHERE account_num = '$account_num'";
        $result2 = $conn->query($sql2);
        $row2 = $result2->fetch_assoc();

        if($result1->num_rows > 0){
        

        if($result2->num_rows > 0){
            echo '<script>alert("You have already registerd for Internet banking, you cannot register again")
            location="customer_login.php"</script>';
        }

        elseif( $password != $cnfrm_password){

            echo '<script>alert("Password and Confirm password should be same")</script>';

        }

        else{
            $banking_id = rand(10,99).mt_rand(100,9999);

            //$conn->autocommit(FALSE);
            //$password = password_hash($_POST['password'], PASSWORD_BCRYPT);

            $sql="INSERT into banklogin (account_num,password,banking_id) VALUES('$account_num','$password','$banking_id')";
		    $conn->query($sql);

		    if($result=$conn->query($sql)== TRUE){

				
			echo '<script>alert("Registration Successfull\n\n Banking ID : '.$banking_id.' \n\nPlease use this customer id to login") location="customer_login.php </script>';
			
            }
        } 

     }

            else{

                echo '<script>alert("Account number not found")</script>';
            }

        }
        }

?>

	
	
<?php include'footer.php';?>
    
    </body>
</html>