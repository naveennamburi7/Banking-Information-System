-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Banking_project
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `customer` (
  `account_num` int(10) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `mobile_no` int(20) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `addrs` varchar(45) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `zip` int(5) DEFAULT NULL,
  `acctype` varchar(15) DEFAULT NULL,
  `balance` int(15) DEFAULT '0',
  PRIMARY KEY (`account_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (14886777,'Asif','Male',981899078,'1994-07-10','','US','Texas','Los Angeles',76202,'Saving',59070),(16663124,'point','Male',789278899,'2021-11-07','','US','Texas','Los Angeles',76201,'Saving',310969),(16861204,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0),(18128729,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0),(24494445,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0),(28306323,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0),(30826577,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0),(45844743,'s','Male',1231231231,'2021-11-23','','US','Texas','Los Angeles',74737,'Saving',819628),(46205591,'nass','Male',1,'2021-11-01','','US','Texas','Los Angeles',5678,'Saving',0),(55639407,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0),(70610231,'Nikhi','Male',987654567,'2021-10-20','','US','Texas','Los Angeles',98675,'Saving',131052),(81683485,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0),(85321148,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0),(85976946,'jhb','Male',1,'2021-11-11','','US','Texas','Los Angeles',6782,'Saving',0);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-28 12:39:10
